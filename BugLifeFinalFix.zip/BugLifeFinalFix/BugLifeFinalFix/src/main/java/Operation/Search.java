
package Operation;
import BugLifeClasses.Project;
import java.util.ArrayList;
import java.util.Scanner;
public class Search{
    String syntax;
    Project project;
    Project projectList;
    public void assignProject(Project projectList){
        this.projectList = projectList;
        project = projectList;
    }
    
    public boolean test(){
        String[] check;
        for(int i=0; i<project.getIssues().size(); i++){
            check = project.getIssues().get(i).getDescriptionText().split(" ");
            for(int j=0; j<check.length; j++){
            if(check[j].contains(syntax))
            return true;
            }
    }
        return false;
    }
    
    public String test1(){
        String check = project.getIssues().get(0).getDescriptionText();
        System.out.println(check);
        if(check.toLowerCase().contains(syntax.toLowerCase())){
            return "dapat";
        
        }
         return "x dapat";
    }
    
    public void doSearch(){
        Scanner s = new Scanner(System.in);
        syntax = s.nextLine();
        System.out.print("_________________________\n");
        //System.out.print(test1());
        if(checkSearchInTitle(syntax) == true){
        searchInTitle(syntax);
        }else if(checkSearchInDescriptiveText(syntax) == true){
        searchInDescriptiveText(syntax);
        }else if(checkSearchInComment(syntax) == true){
        searchInComment(syntax);
        }
    }
    
    public Boolean searchInTitle(String syntax){
        String[] check;
        for(int i=0; i<project.getIssues().size(); i++){
            check = project.getIssues().get(i).getTitle().split(" ");
        for(int j=0; j<check.length; j++){
            if(syntax.contains(check[j]) == true){
                issueList(i);
            return true;
            }
        }
        }
        return false;
    }
    
    public Boolean checkSearchInTitle(String syntax){
        String[] check;
        for(int i=0; i<project.getIssues().size(); i++){
            check = project.getIssues().get(i).getTitle().split(" ");
            for(int j=0; j<check.length; j++){
            if(syntax.contains(check[j])){
                System.out.println("\""+syntax+"\" appears in the title");
                System.out.println("Displaying full result of issue found that matches the word \""+syntax+"\"");
            return true;
            }
            }
    }
        return false;
    }
    
    public Boolean searchInDescriptiveText(String syntax){
        String check;
        for(int i=0; i<project.getIssues().size(); i++){
            check = project.getIssues().get(i).getDescriptionText();
            
            if(check.toLowerCase().contains(syntax.toLowerCase())){
                issueList(i);
                return true;
            
        }
        }
        return false;
    }
    
    public Boolean checkSearchInDescriptiveText(String syntax){
        String check;
        for(int i=0; i<project.getIssues().size(); i++){
            check = project.getIssues().get(i).getDescriptionText();
           
            if(check.toLowerCase().contains(syntax.toLowerCase())){
            System.out.println("\""+syntax+"\" appears in the description text");
            System.out.println("Displaying full result of issue found that matches the word \""+syntax+"\"");
            return true;
            }
    }
        return false;
    }
    public void searchInComment(String syntax){
        String check;
        for(int i=0; i<project.getIssues().size(); i++){
        for(int j=0; j<project.getIssues().get(i).getComments().size(); j++){
            check = project.getIssues().get(i).getComments().get(j).getText();
            if(check.toLowerCase().contains(syntax.toLowerCase())){
                issueList(i);
                break;
            }
        }
        }   
    }
    
    public Boolean checkSearchInComment(String syntax){
        String check;
        for(int i=0; i<project.getIssues().size(); i++){
            for(int j=0; j<project.getIssues().get(i).getComments().size(); j++){
            check = project.getIssues().get(i).getComments().get(j).getText();
            if(check.toLowerCase().contains(syntax.toLowerCase())){
            System.out.println("\""+syntax+"\" appears in the comment");
            System.out.println("Displaying full result of issue found that matches the word \""+syntax+"\"");
            return true;
            }
            }
            
    }
        return false;
    }
    
    public void issueList(int i){
        
                System.out.println("Id ="+String.valueOf(project.getIssues().get(i).getId()));
                System.out.println("Title ="+String.valueOf(project.getIssues().get(i).getTitle()));
                System.out.println("Priority ="+String.valueOf(project.getIssues().get(i).getPriority()));
                System.out.println("Status ="+String.valueOf(project.getIssues().get(i).getStatus()));
                System.out.println("Tag ="+String.valueOf(project.getIssues().get(i).getTag()));
                System.out.println("Description Text ="+String.valueOf(project.getIssues().get(i).getDescriptionText()));
                System.out.println("Created By ="+String.valueOf(project.getIssues().get(i).getCreatedBy()));
                System.out.println("Assignee ="+String.valueOf(project.getIssues().get(i).getAssignee()));
                System.out.println("Timestamp ="+String.valueOf(project.getIssues().get(i).getTimestamp()));
                System.out.println("Comments:");
                commentList(i);
            
    }
    public void commentList(int i){
        for(int j=0; j<project.getIssues().get(i).getComments().size(); j++){
            System.out.println("\n*-*-*-*-*-*-*-*-*-*");
            System.out.println("Comment Id ="+String.valueOf(project.getIssues().get(i).getComments().get(j).getComment_id()));
            System.out.println("Text ="+String.valueOf(project.getIssues().get(i).getComments().get(j).getText()));
            System.out.println("React:");
            reactList(i,j);
            System.out.println("Time stamp ="+String.valueOf(project.getIssues().get(i).getComments().get(j).getTimestamp()));
            System.out.println("User ="+String.valueOf(project.getIssues().get(i).getComments().get(j).getUser()));
            System.out.println("\n*-*-*-*-*-*-*-*-*-*");
        }
        
    }
    public void reactList(int i, int j){
        for(int p=0; p<project.getIssues().get(i).getComments().get(j).getReact().size();p++){
            System.out.println("Reaction ="+String.valueOf(project.getIssues().get(i).getComments().get(j).getReact().get(p).getReaction()));
            System.out.println("Count ="+String.valueOf(project.getIssues().get(i).getComments().get(j).getReact().get(p).getCount()));
        }
    }
    
    }
    
    

