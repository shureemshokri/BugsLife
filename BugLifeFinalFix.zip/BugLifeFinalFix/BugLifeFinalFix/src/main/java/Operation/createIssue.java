
package Operation;

/**
 *
 * @author Shureem Shokri
 */
import BugLifeClasses.Comment;
import BugLifeClasses.Issue;
import BugLifeClasses.Person;
import BugLifeClasses.Project;
import BugLifeJSON.ReadJSONFile;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.util.Scanner;
import java.util.ArrayList;
public class createIssue {
    
    Session current;
    // Instance Variable
    Project issueList;
    int currentProjectIndex;
    Scanner input = new java.util.Scanner(System.in);

    public createIssue(Session current) {
        this.current = current;
    }
    
    
    
    public createIssue(Project issueList)
    {
        this.issueList = issueList;
    }
    
    
    // Receive Input and add into list              NI METHOD UTK CREATE ISSUE
    public void receiveInput(int index) throws IOException, FileNotFoundException, ParseException, org.json.simple.parser.ParseException
    {
        ReadJSONFile read = new ReadJSONFile();
        currentProjectIndex = index;
        int issueID = read.projectList.get(currentProjectIndex).getIssues().size()+1;
        
        
        System.out.println("Enter priority: ");
        int priority = input.nextInt();
        
        input.nextLine();
        
        System.out.println("Enter issue Title: ");
        String issueTitle = input.nextLine();
        
        System.out.println("Enter issue Status: ");
        String status = input.nextLine();
        
        System.out.println("Enter issue tag: "); //Do while loop
        ArrayList<String> tag = new ArrayList<>();
        tag.add(input.nextLine());
        
        System.out.println("Enter assignee: ");
        String assignee = input.nextLine();
        
        String creator = current.username;
        
        System.out.println("Enter description: ");
        String description = input.next();
        
        Issue newIssue = new Issue(issueID,issueTitle,priority,status,tag,description,creator,assignee);
        issueList = read.projectList.get(index);
        issueList.getIssues().add(newIssue);
    }
    
    // addComment
    public void addComment(int index) throws IOException, FileNotFoundException, ParseException, org.json.simple.parser.ParseException               //add comm dekat which issue
    {
        ReadJSONFile read = new ReadJSONFile();
        System.out.println("Enter Comment Text: ");
        String comment_text = input.nextLine();
        
        int comment_ID = read.projectList.get(currentProjectIndex).getIssues().get(index).getComments().size()+1;
        
        // cari issue mana yang dia nak comment, boleh cari guna index value, contoh nak comment dkt issue yang index 0
        issueList.getIssues().get(currentProjectIndex).getComments().add(new Comment(comment_ID,comment_text,current.username));
        
    }

    @Override
    public String toString() {
        return "createIssue{" + "issueList=" + issueList + "\n";
    }
    
}
