/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Operation;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author Shureem Shokri
 */
public class StackUndoRedo<E> {
    
    
     private ArrayList<E> list = new ArrayList<>();
     
     public int getSize() {return list.size();}
     public E peek(){return list.get(getSize()-1);}
     public void push(E anything) {list.add(anything);}
     public E pop(){
        E anything  = list.get(getSize() - 1);
        list.remove(getSize()-1);
        return anything;
     }
    public boolean isEmpty() {return list.isEmpty();}   
    @Override
    public String toString() {
        return "[ " + list;
    }
    
    
    
    
    public void undoRedo () {
        
         Scanner in = new Scanner(System.in);
        //main stack
        StackUndoRedo<String> ori = new StackUndoRedo<>();
        //deleted stack
        StackUndoRedo<String> temp = new StackUndoRedo<>();
        
        try{
            JSONParser jsonP = new JSONParser();
            FileReader reader = new FileReader("data.json");
            Object obj = jsonP.parse(reader);
            JSONObject jsonObj = (JSONObject) obj;
            JSONArray array = (JSONArray) jsonObj.get("projects");
            for(int i = 0; i<array.length(); i++){
                //System.out.println("MAIN : " + array.get(i));
                JSONObject project = (JSONObject) array.get(i);
                String name = (String) project.get("name");
                long id = (Long) project.get("id");
                JSONArray issue = (JSONArray) project.get("issues");
                System.out.println("------------------------------------");
                System.out.println("Name: "+name+ "   |   ID: "+ id);
                System.out.println("------------------------------------");
                for(int j = 0; j<issue.length(); j++){
                    String sign;
                    JSONObject issues = (JSONObject) issue.get(j);
                    //System.out.println("IN ISSUE"+ (i+1) + " : " + issue);
                    String text = (String) issues.get("descriptionText");
                    System.out.println("Issue Description " + (j+1));
                    System.out.println("-------------------------------------");
                    System.out.println(text);
                    System.out.println("=====================================");
                    System.out.println("");
                    do{       
                        System.out.println("Enter\n'a' to add\n'u' to undo\n'r; to redo\n'e' to exit");
                        sign = in.nextLine();
                        if(sign.equals("a")){
                            System.out.print("Enter any sentences: ");
                            String insert = in.nextLine();
                            ori.push(insert);
                            System.out.println(text+ori.toString().replaceAll("\\[", "").replaceAll("]", "").replaceAll(",", ""));
                            //System.out.println(ori);
                            //System.out.println(temp);
                        }
                        if(sign.equals("u")){
                            if(ori.getSize()==0){
                                System.out.println("Cannot undo!");
                            }
                            else{
                                temp.push(ori.pop());
                                System.out.println(text+ori.toString().replaceAll("\\[", "").replaceAll("]", "").replaceAll(",", ""));
                                //System.out.println(ori);
                                //System.out.println(temp);
                            }    
                        }
                        if(sign.equals("r")){
                            if(temp.getSize()==0){
                                System.out.println("Cannot redo!");
                            }
                            else{
                                ori.push(temp.pop());
                                System.out.println(text+ori.toString().replaceAll("\\[", "").replaceAll("]", "").replaceAll(",", ""));
                                //System.out.println(ori);
                                //System.out.println(temp);
                            }  
                        }
                    }while(!sign.equals("e"));
                    System.out.println("End");
                    String newText = text+ori.toString().replaceAll("\\[", "").replaceAll("]", "").replaceAll(",", "");
                    System.out.println(newText);
                    System.out.println("\n\n\n\n");
                }
            }         
        }catch(IOException e){
            e.printStackTrace();
            
        }catch(ParseException e) {
            e.printStackTrace();
        }
    }
    
}
