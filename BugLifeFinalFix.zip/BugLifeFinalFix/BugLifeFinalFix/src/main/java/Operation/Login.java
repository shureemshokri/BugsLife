/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Operation;
import BugLifeJSON.ReadJSONFile;
import Dashboard.IssueDashboard;
import Dashboard.projectDashboard;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.util.Scanner;

/**
 *
 * @author Shureem Shokri
 */
public class Login {
    int selectedProject, selectedIssue, selectedComment;
    Session current;
    Scanner s = new Scanner(System.in);
    IssueDashboard issueDash;
    
    private String username,pass;

    public Login() {        
        this.username = "";           //login username
        this.pass = "";       //login pass
    }

    public String getID() {
        username=s.nextLine();
        return username;
    }

    public void setID(String username) {
        this.username = username;
    }

    public String getPass() {
        pass = s.nextLine();
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
    
    public void getAccess() throws IOException, FileNotFoundException, ParseException, org.json.simple.parser.ParseException {          //parameter a as no of tries 
      
        ReadJSONFile readUser = new ReadJSONFile();
     for(int i=0; i<readUser.userList.size(); i++){
       if(username.equals(readUser.userList.get(i).getName()) && pass.equals(readUser.userList.get(i).getLoginPass())) {
           
           System.out.println("Login Succesful !");
           System.out.println("");
           System.out.println("Welcome " + username);
           current = new Session(readUser.userList.get(i).getLoginID(),username); 
           projectDashboard projectDash = new projectDashboard();
           System.out.println("Select project id:");
           selectedProject = projectDash.chooseProject()-1;
           issueDash = new IssueDashboard(selectedProject,"");
           break;
       }
       else {
           System.out.println("Access Denied.");
           System.out.println("Please try Again.");
           exit();
       }
     }
        }
    
    
    public void choice(int a) throws IOException, FileNotFoundException, ParseException, org.json.simple.parser.ParseException {     //accept parameter from scanner
       
        
        switch (a) {
            
            case 1 : System.out.println("u choose to 1 : Check Issues");
            issueDash.addSession(current);
            issueDash.selectIssue(selectedProject);
            Scanner s = new Scanner(System.in);
            
            selectedIssue = s.nextInt()-1;
            break;
            
            case 2 : System.out.println("u chose to 2 : Create New Issue ");
              createIssue create = new createIssue(current);
              create.receiveInput(selectedProject);
            
            break;
            
            case 3 : System.out.println("u chose to 3 : Comment on Issues");
            break;
            
            case 4 : System.out.println("u chose to 4 : React to Issue");
            break;
            
            case 5 : System.out.println("u chose to 5 : Exit");
                      System.out.println("Thank You. See You Soon!");
                      exit();
            break;
              }
            
        }
    
    public void printIssue() throws IOException, FileNotFoundException, ParseException, org.json.simple.parser.ParseException{
        ReadJSONFile read = new ReadJSONFile();
                System.out.println("Id ="+read.projectList.get(selectedProject).getIssues().get(selectedIssue).getId());
                System.out.println("Title ="+read.projectList.get(selectedProject).getIssues().get(selectedIssue).getTitle());
                System.out.println("Priority ="+read.projectList.get(selectedProject).getIssues().get(selectedIssue).getPriority());
                System.out.println("Status ="+read.projectList.get(selectedProject).getIssues().get(selectedIssue).getStatus());
                System.out.println("Tag ="+read.projectList.get(selectedProject).getIssues().get(selectedIssue).getTag());
                System.out.println("Description Text ="+read.projectList.get(selectedProject).getIssues().get(selectedIssue).getDescriptionText());
                System.out.println("Created By ="+read.projectList.get(selectedProject).getIssues().get(selectedIssue).getCreatedBy());
                System.out.println("Assignee ="+read.projectList.get(selectedProject).getIssues().get(selectedIssue).getAssignee());
                System.out.println("Timestamp ="+read.projectList.get(selectedProject).getIssues().get(selectedIssue).getTimestamp());
                System.out.println("Comments:");
                printComment();
            
    }
    
    public void printComment() throws IOException, FileNotFoundException, ParseException, org.json.simple.parser.ParseException{
        ReadJSONFile read = new ReadJSONFile();
        for(int k=0; k<read.projectList.get(selectedProject).getIssues().get(selectedIssue).getComments().size();k++){
            System.out.println("\n*-*-*-*-*-*-*-*-*-*");
            System.out.println("Comment Id ="+read.projectList.get(selectedProject).getIssues().get(selectedIssue).getComments().get(k).getComment_id());
            System.out.println("Text ="+read.projectList.get(selectedProject).getIssues().get(selectedIssue).getComments().get(k).getText());
            System.out.println("React:");
            selectedComment = k;
            printReact();
            System.out.println("Time stamp ="+read.projectList.get(selectedProject).getIssues().get(selectedIssue).getComments().get(k).getTimestamp());
            System.out.println("User ="+read.projectList.get(selectedProject).getIssues().get(selectedIssue).getComments().get(k).getUser());
            System.out.println("\n*-*-*-*-*-*-*-*-*-*");
        }
    }
    
    public void printReact() throws IOException, FileNotFoundException, ParseException, org.json.simple.parser.ParseException{
        ReadJSONFile read = new ReadJSONFile();
        for(int p=0; p<read.projectList.get(selectedProject).getIssues().get(selectedIssue).getComments().get(selectedComment).getReact().size();p++){
            System.out.println("Reaction ="+read.projectList.get(selectedProject).getIssues().get(selectedIssue).getComments().get(selectedComment).getReact().get(p).getReaction());
            System.out.println("Count ="+read.projectList.get(selectedProject).getIssues().get(selectedIssue).getComments().get(selectedComment).getReact().get(p).getCount());
        }
    }
    public void exit() {
        System.exit(0);
    }
    
    
    
    
}
