
package BugLifeJSON;

import BugLifeClasses.Person;
import BugLifeClasses.Project;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;


/**
 *
 * @author Shureem Shokri
 */
public class ReadJSONFile {
    
           public ArrayList<Project> projectList = new ArrayList<>();
           public ArrayList<Person> userList = new ArrayList<>();
           
     public ReadJSONFile() throws FileNotFoundException, IOException, ParseException, org.json.simple.parser.ParseException{
      
        ArrayList<Person> user = new ArrayList<>();
        
        JSONParser jsonParser = new JSONParser();
        //Read the data.json
        FileReader reader = new FileReader("data.json");
        //Create objects from the file
        Object obj = jsonParser.parse(reader);
        //Casting Object obj to org.json.simple.JSONObject    
        org.json.simple.JSONObject jo = (org.json.simple.JSONObject) obj;
        //Create new JSONObject from org.json.simple.JSONObject    
        JSONObject BugObj = new JSONObject(jo);
                //Create JSONArray from the file which are the JSONObject called "projects"
                JSONArray foundUsers = BugObj.getJSONArray("users");
                //Loop for every project found
                for(int i = 0;i<foundUsers.length(); i++){
                    //Create JSONObject from every project to find its element
                    JSONObject projectObject = foundUsers.getJSONObject(i);
                    //Search for String value from the JSONObject called "name"
                    int userID = projectObject.getInt("userid");
                    //Search for int value from the JSONObject called "id"
                    String userName = projectObject.getString("username");
                    //Search for int value from the JSONObject called "id"
                    String password = projectObject.getString("password");
                    user.add(new Person(userID, userName, password));
                }
                this.userList = user;
                    

            
            //Create ArrayList for Project
        ArrayList<Project> project = new ArrayList<>();
        //Create new JSONObject from org.json.simple.JSONObject    
        JSONObject resObj = new JSONObject(jo);
                //Create JSONArray from the file which are the JSONObject called "projects"
                JSONArray foundProjects = resObj.getJSONArray("projects");
                //Loop for every project found
                for(int i = 0;i<foundProjects.length(); i++){
                    //Create JSONObject from every project to find its element
                    JSONObject projectObject = foundProjects.getJSONObject(i);
                    //Search for String value from the JSONObject called "name"
                    String title = projectObject.getString("name");
                    //Search for int value from the JSONObject called "id"
                    int id = projectObject.getInt("id");
                    //Create JSONArray for the issues. Found from the JSONObject of the projects.
                    JSONArray foundIssues = projectObject.getJSONArray("issues");
                    //JSONArray foundTag = foundIssues.getJSONArray("tag");
                project.add(new Project(id,title));
                project.get(i).addIssue(foundIssues);
            }
            this.projectList = project;
      
                 
     }
     
    
     
        
     
     
     
     
     
     
     
   
}


 

