/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dashboard;

import BugLifeClasses.Project;
import BugLifeJSON.ReadJSONFile;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Time;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.PriorityQueue;
import java.util.Scanner;
import org.json.JSONArray;
import org.json.JSONObject;


/**
 *
 * @author Shureem Shokri
 */
public class projectDashboard<E>{
    
     
     
   private  PriorityQueue<E> pq = new PriorityQueue<>();
   
   

    public projectDashboard() throws IOException, FileNotFoundException, ParseException, org.json.simple.parser.ParseException {
        ReadJSONFile read = new ReadJSONFile(); 
        
        System.out.println("+-----+----------------------------------------------------------+----------+");
        System.out.println("| ID  |             Project Name                                 |   Issues |");
        System.out.println("+-----+----------------------------------------------------------+----------+");
        
        for(int i=0; i<read.projectList.size(); i++){
            System.out.printf("| %d   |   %-5s                                                |     %d    |\n", read.projectList.get(i).getId(), read.projectList.get(i).getName(),read.projectList.get(i).getIssues().size());
        }
        System.out.println("+-----+----------------------------------------------------------+----------+");
    }
    
    public int chooseProject(){
        Scanner s = new Scanner(System.in);
        int index = s.nextInt();
        return index;
    }
    
    public void readUser(int i) {
        try {
              String files = new String((Files.readAllBytes(Paths.get("data.json"))));
            JSONObject o = new JSONObject(files);

            
            
            System.out.println("");
            
            //read username in json file
            JSONArray users = o.getJSONArray("users");
            JSONObject obj =users.getJSONObject(i);         //utk cari array user 
            
            String username =obj.getString("username");
            String pass =obj.getString("password");
            int id=obj.getInt("userid");
            System.out.println("password : " +pass);
            System.out.println("user ID : " +id);
            System.out.println("username : " +username);
            System.out.println("");
            
            
            
            
            
        }catch (IOException e) {
            System.out.println("error");
        }
    }
    
    
    public void readProjectId(int u,int a, int b,int c) {     //int u for which proj // int a for which issue // int b for which comment // int c for which reaction
        
        //read from json file 
        try{ 
             String files = new String((Files.readAllBytes(Paths.get("data.json"))));
            JSONObject o = new JSONObject(files);
            
            JSONArray projects =o.getJSONArray("projects");
            JSONObject obj1 =projects.getJSONObject(u);     //project 1
            int idProj = obj1.getInt("id");
            String projname=obj1.getString("name");
            
            ///BELOW IS THE TESTER UTK READ JSON FILE
            
            System.out.println("PROJECT ");
            System.out.println("----------------------------");
            System.out.println("Project ID : "+ idProj); 
            System.out.println("Project name: "+ projname);
            System.out.println("----------------");
            
            System.out.println("ISSUE");
            System.out.println("-----------------------------");
            
            //read apa dalam issue array
           JSONArray issue =obj1.getJSONArray("issues");
           JSONObject obj2=issue.getJSONObject(a);             //get issue array at first index ==0
           
           int issueId= obj2.getInt("id");
           String title = obj2.getString("title");
           int priority = obj2.getInt("priority");
           String status = obj2.getString("status");
           String creator = obj2.getString("createdBy");
           String assign = obj2.getString("assignee");

           long time =obj2.getLong("timestamp");
           
           String text= obj2.getString("descriptionText");
           
           JSONArray tag=obj2.getJSONArray("tag");
           
           
           
           
            System.out.println("Issue Id: " + issueId);
           System.out.println("Issue Title: " + title) ;
            System.out.println("Priority: "+ priority);
            System.out.println("Status : "+ status);
            System.out.println("Tag :" + tag.getString(0));
            System.out.println("Created By : "+ creator);
            System.out.println("Assignee: " + assign);
            System.out.println("Time : " + time);
            
            System.out.println(""+ text);
            
            System.out.println("");
            System.out.println("COMMENT");
            
            //COMMENT ARRAY DALAM ISSUE ARRAY
             JSONArray comArr = obj2.getJSONArray("comments");
            JSONObject com=comArr.getJSONObject(b);                  //get comment array
            
            System.out.println("");                             //start reading comment array
            int comId=com.getInt("comment_id");
            String comText= com.getString("text");
            
            System.out.println("Comment ID : " + comId);
            System.out.println(" "+ comText);
            
           
                    //READ REACT ARRAY IN ISSUE ARRAY
                    
            System.out.println(""); 
            System.out.println("REACTION");
           JSONArray react=com.getJSONArray("react");
           JSONObject reactInd=react.getJSONObject(c);
           
           
            String reaction =reactInd.getString("reaction");
            int reactId= reactInd.getInt("count");
           
            System.out.println("Reaction :" + reaction);
            System.out.println("Count : "+ reactId);
            
            System.out.println("");
            
            
            
            
        }catch(IOException e) {
            System.out.println("error");
        }
        
        
        
    }
    
    
    
        public void getChoice() {
            Scanner s = new Scanner(System.in);
            System.out.println("Choose which ID project you would like to view [1-3] : ");
            int a=s.nextInt();
        }
        
       
            
        
    
    
}
