
package BugLifeClasses;

public class React {
    String reaction;
    int count;

    public React(String reaction, int count) {
        this.reaction = reaction;
        this.count = count;
    }

    public String getReaction() {
        return reaction;
    }

    public int getCount() {
        return count;
    }

    public void setReaction(String reaction) {
        this.reaction = reaction;
    }

    public void setCount(int count) {
        this.count = count;
    }
    
    public void addReaction(String r){
        
    }
    
}
