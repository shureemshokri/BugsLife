
package BugLifeClasses;

import java.util.ArrayList;

public class Comment {
    int comment_id;
    String text;
    ArrayList<React> react;
    int timestamp;
    String user;

    public Comment(int comment_id, String text, ArrayList<React> react, int timestamp, String user) {
        this.comment_id = comment_id;
        this.text = text;
        this.react = react;
        this.timestamp = timestamp;
        this.user = user;
    }
    
    public Comment(int comment_id,String text, String user) {
        this.comment_id = comment_id;
        this.text = text;
        this.user = user;
    }

    public int getComment_id() {
        return comment_id;
    }

    public String getText() {
        return text;
    }

    public ArrayList<React> getReact() {
        return react;
    }
    
    public void addReact(String r){
        for(int i=0;i<react.size();i++){
            if(react.get(i).reaction.equalsIgnoreCase(r)){
                react.get(i).count++;
                break;
            }
        }react.add(new React(r,1));
    }

    public int getTimestamp() {
        return timestamp;
    }

    public String getUser() {
        return user;
    }

    public void setComment_id(int comment_id) {
        this.comment_id = comment_id;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setReact(ArrayList<React> react) {
        this.react = react;
    }

    public void setTimestamp(int timestamp) {
        this.timestamp = timestamp;
    }

    public void setUser(String user) {
        this.user = user;
    }
    
    
}
