
package Main;

import Operation.Login;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Shureem Shokri
 */
public class Tester {
    
    public static void main (String [] args) throws IOException, FileNotFoundException, ParseException, org.json.simple.parser.ParseException {
       
        //IssueDash b = new IssueDash();
       // ArrayList<Issue> b =new ArrayList<>();
        
   
//         projectDashboard pd = new projectDashboard();
//            pd.readProjectId(0,0,0,0);
      
       
        User();
        
         //a.readProjId();
         //a.readProjName();
        
//         pd.readUser(0);
//         pd.readUser(1);
//         pd.readUser(2);
//         pd.readUser(3);
       
        
        
       
         
       
    }
    
    
    
    
     public static void User() throws IOException, FileNotFoundException, ParseException, org.json.simple.parser.ParseException {     //method for the users who logged in
         
         Scanner s = new Scanner(System.in) ; 
         
        System.out.println("Please Login");
        
        Login user1 = new Login();
         System.out.println("Enter your ID: ");
         user1.getID();
         
         System.out.println("Enter password: ");
         
         user1.getPass();
         
            user1.getAccess();
        
          
        System.out.println("1. Check Issues");
        System.out.println("2. Create New Issue");
        System.out.println("3. Comment on Issues");
        System.out.println("4. React on Issues");
        System.out.println("5. Exit");
        System.out.println("choose [1-5]");
        
        int ch=s.nextInt(5 + 1);
        
        
                   //call choice in proj dashboard
          //   pd.getChoice();
        user1.choice(ch);
        
        //test
//        PriorityQueue<String> te= new PriorityQueue<>();
//        te.add("test");
//        te.add("Hello");
//        te.add("Wazzup");
        
        
       
         //    pd.readProjectId(0,0,0,1);
        
    }
     
     
}
