/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.buglifefinalfix;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Shureem Shokri
 */
public class Issue {
    
    int id;
    String title;
    int priority;
    String status;
    ArrayList<String> tag; //to be check
    String descriptionText;
    String createdBy;
    String assignee;
    int timestamp;
    ArrayList<Comment> comments;

    public Issue(int id){
        this.id = id;
    }
    
    
    public Issue(int id, String title, int priority, String status, ArrayList<String> tag, String descriptionText, String createdBy, String assignee, int timestamp, ArrayList<Comment> comments) {
        this.id = id;
        this.title = title;
        this.priority = priority;
        this.status = status;
        this.tag = tag;
        this.descriptionText = descriptionText;
        this.createdBy = createdBy;
        this.assignee = assignee;
        this.timestamp = timestamp;
        this.comments = comments;
    }
    
    public Issue(int id, String title, int priority, String status, ArrayList<String> tag, String descriptionText, String createdBy, String assignee) {
        this.id = id;
        this.title = title;
        this.priority = priority;
        this.status = status;
        this.tag = tag;
        this.descriptionText = descriptionText;
        this.createdBy = createdBy;
        this.assignee = assignee;
        this.timestamp = timestamp;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public int getPriority() {
        return priority;
    }

    public String getStatus() {
        return status;
    }

    public ArrayList<String> getTag() {
        return tag;
    }

    public String getDescriptionText() {
        return descriptionText;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public String getAssignee() {
        return assignee;
    }

    public int getTimestamp() {
        return timestamp;
    }

    public ArrayList<Comment> getComments() {
        return comments;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setTag(ArrayList<String> tag) {
        this.tag = tag;
    }

    public void setDescriptionText(String descriptionText) {
        this.descriptionText = descriptionText;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public void setAssignee(String assignee) {
        this.assignee = assignee;
    }

    public void setTimestamp(int timestamp) {
        this.timestamp = timestamp;
    }

    public void setComments(ArrayList<Comment> comments) {
        this.comments = comments;
    }
    
    
    public void addComment(int id, String c, String username){
        comments.add(new Comment(id, c, username));
    }
    
    
}
