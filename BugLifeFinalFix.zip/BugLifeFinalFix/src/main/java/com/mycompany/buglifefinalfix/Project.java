/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.buglifefinalfix;

/**
 *
 * @author Shureem Shokri
 */

import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

public class Project {
    
    
     int id;
    String name;
    ArrayList<Issue> issues = new ArrayList<>();
    
    
    public Project(){
        this.id = 0;
        this.name = null;
        this.issues = null;
    }
    
    public Project(int id, String name) {
        this.id = id;
        this.name = name;
    }
    
    public Project(int id, String name,ArrayList<Issue> issues) {
        this.id = id;
        this.name = name;
        this.issues = issues;
    }
    
    public void addIssue(JSONArray foundIssues){
        ArrayList<Issue> issueList = new ArrayList<>();
        for(int j = 0;j<foundIssues.length(); j++){
                    JSONObject issuesObject = foundIssues.getJSONObject(j);
                    JSONArray issuesTag = issuesObject.getJSONArray("tag");
                    JSONArray issuesComment = issuesObject.getJSONArray("comments");
                    
                    int issueId = issuesObject.getInt("id");
                    String title = issuesObject.getString("title");
                    int priority = issuesObject.getInt("priority");
                    String status = issuesObject.getString("status");
                    //String[] tag = issuesObject.get("tag");
                    ArrayList<String> tag = addTag(issuesTag);
                    String descriptionText = issuesObject.getString("descriptionText");
                    String createdBy = issuesObject.getString("createdBy");
                    String assignee = issuesObject.getString("assignee");
                    int timestamp = issuesObject.getInt("timestamp");
                    //Comment[] comments = issuesObject.getInt("comments");
                    ArrayList<Comment> comments = addComment(issuesComment);
                    Issue issue = new Issue(issueId, title, priority, status, tag, descriptionText, createdBy, assignee, timestamp, comments);
                    issueList.add(issue);
                }
        //So that issueList and issueListTemp will not refer to the same object. Thus, it is safe to clear the former.
        ArrayList<Issue> issueListTemp = (ArrayList<Issue>) issueList.clone();
        issueList.clear();
                issues = issueListTemp;
    }
    
    public ArrayList<String> addTag(JSONArray issuesTag){
        ArrayList<String> tag = new ArrayList<>();
        for(int i = 0;i<issuesTag.length();i++ ){
            tag.add(issuesTag.getString(i));
        }
        return tag;
    }
    
    public ArrayList<Comment> addComment(JSONArray issuesComment){
        ArrayList<Comment> commentList = new ArrayList<>();
        for(int i = 0;i<issuesComment.length(); i++){
                    //Create JSONObject from every project to find its element
                    JSONObject commentObject = issuesComment.getJSONObject(i);
                    JSONArray commentReact = commentObject.getJSONArray("react");
                    //Search for String value from the JSONObject called "name"
                    int commentId = commentObject.getInt("comment_id");
                    String text = commentObject.getString("text");
                    ArrayList<React> react= addReact(commentReact);
                    int timestamp = commentObject.getInt("timestamp");
                    String user = commentObject.getString("user");
                    
                    Comment comment = new Comment(commentId, text, react, timestamp, user);
                    commentList.add(comment);
    }
        return commentList;
    }
    public ArrayList<React> addReact(JSONArray commentReact){
        ArrayList<React> reactList = new ArrayList<>();
        for(int j = 0;j<commentReact.length(); j++){
                    JSONObject commentObject = commentReact.getJSONObject(j);
                    
                    String reaction = commentObject.getString("reaction");
                    int count = commentObject.getInt("count");
                    React react = new React(reaction, count);
                    reactList.add(react);
    }
        return reactList;
    }
    

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public ArrayList<Issue> getIssues() {
        return issues;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setIssues(ArrayList<Issue> issues) {
        this.issues = issues;
    }

    @Override
    public String toString() {
        return "Project{" + "id=" + id + ", name=" + name + ", issues=" + issues + '}';
    }
}
