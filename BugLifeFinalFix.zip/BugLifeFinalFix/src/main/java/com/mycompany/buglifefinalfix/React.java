/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.buglifefinalfix;

import java.util.Scanner;

/**
 *
 * @author Shureem Shokri
 */
public class React {
    
      String reaction;
      int count;
      Scanner s=new Scanner(System.in);

    
    public React(String reaction, int count) {
        this.reaction = reaction;
        this.count = count;
    }

    public String getReaction() {
        return reaction;
    }

    public int getCount() {
        return count;
    }

    public void setReaction(String reaction) {
        this.reaction = reaction;
    }

    public void setCount(int count) {
        this.count = count;
    }
    
    public void addReaction(String r){
        
    }
}
