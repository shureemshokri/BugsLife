/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.buglifefinalfix;

/**
 *
 * @author Shureem Shokri
 */
public class Person {
    
    // Instance Variable
    private String Name;
    private int loginID;
    private String loginPass;
    private int UACLevel;
    
    public Person(){
        
    }
    
     // Constructor                              
    public Person(int ID, String Name, String loginPass)          //add new user maybe
    {
        this.Name = Name;
        this.loginID = ID;
        this.loginPass = loginPass; 
    }
    
    // Getter and Setter
    public String getName() 
    {
        return Name;
    }

    public void setName(String Name) 
    {
        this.Name = Name;
    }

    public int getLoginID() 
    {
        return loginID;
    }

    public void setLoginID(int loginID) 
    {
        this.loginID = loginID;
    }

    public String getLoginPass() 
    {
        return loginPass;
    }

    public void setLoginPass(String loginPass) 
    {
        this.loginPass = loginPass;
    }

    public int getUACLevel() 
    {
        return UACLevel;
    }

    public void setUACLevel(int UACLevel) 
    {
        this.UACLevel = UACLevel;
    }
    
    
    public String getUACLevelString() {
        String uac = "";
        if (getUACLevel() == 0) uac = "Customer";
        if (getUACLevel() == 1) uac = "Admin";
        if (getUACLevel() == 2) uac = "Worker";
        return uac;
    }
    
}
