/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.buglifefinalfix;


import com.mycompany.buglifefinalfix.Search;
import com.mycompany.buglifefinalfix.Session;
import com.mycompany.buglifefinalfix.createIssue;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
/**
 *
 * @author Shureem Shokri
 */
public class IssueDashboard {
    
    Session currentSession;    
        Project issueList;
        
       public void addSession(Session current){
        currentSession = current;
    }    
       
       public IssueDashboard(int index,String nul) throws IOException, FileNotFoundException, java.text.ParseException, ParseException {            //SEBAB MAIN METHOD AIFA ADA DALAM CLASS ISSUEDASH NI BEFORE DIA SUBMIT DEKAT AKU SO AKU JUST CALL OBJECT NI
        
        ReadJSONFile read = new ReadJSONFile();
        
      Table table = new Table();
        table.setShowVerticalLines(true);
        table.setHeaders("ID","Title","Status","Tag","Priority","Time","Assignee","CreatedBy");
        issueList = read.projectList.get(index);
        for(int i = 0; i < read.projectList.get(index).getIssues().size(); i++)
        {
            String id = String.valueOf(issueList.getIssues().get(i).getId());
            String title = issueList.getIssues().get(i).getTitle();
            String status = issueList.getIssues().get(i).getStatus();
            String tag = issueList.getIssues().get(i).getTag().toString();
            String priority = String.valueOf(issueList.getIssues().get(i).getPriority());
            String timestamp = String.valueOf(issueList.getIssues().get(i).getTimestamp());
            String assignee = issueList.getIssues().get(i).getAssignee();
            String createdBy = issueList.getIssues().get(i).getCreatedBy();
            String[] row = {id,title,status,tag,priority,timestamp,assignee,createdBy};
            table.addRow(row);
        }
        
        table.print();
    }
    
    public void selectIssue(int index) throws IOException, FileNotFoundException, java.text.ParseException, ParseException {            //SEBAB MAIN METHOD AIFA ADA DALAM CLASS ISSUEDASH NI BEFORE DIA SUBMIT DEKAT AKU SO AKU JUST CALL OBJECT NI
        
        ReadJSONFile read = new ReadJSONFile();
      
      
           
            
            System.out.println("Enter selected issue ID to check issue");
            System.out.println("choose [1-"+issueList.getIssues().size()+"]");
            System.out.println("or \'s\' to search");
            System.out.println("");
            System.out.println("");
            
            
            
            
            Scanner s = new Scanner(System.in);
            
          String x=s.nextLine();
          
          if(x.equals("s")){
              Search search = new Search();
              search.assignProject(read.projectList.get(index));
              System.out.println("Type anything to search for it inside the project:");
              search.doSearch();
          }else{
          
           try
        {
            // Kalau dia masukkan int, go to issue tu based on index
            issueList.getIssues().get(Integer.parseInt(x)-1);
 		
                
                System.out.println("Issue Description");
                System.out.println("------------------------------");
                System.out.print(issueList.getIssues().get(Integer.parseInt(x)-1).getDescriptionText());
                System.out.println("\nComments");
                System.out.println("------------------------------");
                
                for(int i=0; i<=issueList.getIssues().get(Integer.parseInt(x)-1).getComments().size(); i++) {
                    System.out.print(issueList.getIssues().get(Integer.parseInt(x)-1).getComments().get(i).getComment_id()+". ");
                    System.out.print(issueList.getIssues().get(Integer.parseInt(x)-1).getComments().get(i).getText());
                    System.out.println("\nTime stamp: "+issueList.getIssues().get(Integer.parseInt(x)-1).getComments().get(i).getTimestamp());
                for(int p=0; p<issueList.getIssues().get(Integer.parseInt(x)-1).getComments().get(i).getReact().size();p++){
                    System.out.println("Reaction ="+issueList.getIssues().get(Integer.parseInt(x)-1).getComments().get(i).getReact().get(p).getReaction());
                    System.out.println("Count ="+issueList.getIssues().get(Integer.parseInt(x)-1).getComments().get(i).getReact().get(p).getCount());
                }        
                }
                
                
              
        }
        
        // Kalau dia bukan masukkan int
        catch(Exception e)
        {
            System.out.println("you chose to enter the issue ID.");
            System.out.println("");
        }
           
           
           
           
             System.out.println("\'r\' to react");
                System.out.println("\'c\' to comment");
                System.out.println("");
                System.out.println("");
                
                String z=s.nextLine();
                
                if (z.equals("r")) {
                Scanner input = new Scanner(System.in);
                System.out.println("Choose which comment ID to react");
                int selectCommentID = input.nextInt();
                System.out.println("Choose a reaction. [happy/sad/angry]");
                int q = Integer.parseInt(x)-1;
                String f =s.nextLine();
   
                issueList.getIssues().get(q).getComments().get(selectCommentID).addReact(f);
   
                }
                
                else if (z.equals("c")) {
                    
                Scanner input = new Scanner(System.in);
                System.out.println("Enter your comment ");
                String comment = input.next();
                int comment_id = currentSession.getUserID();
                int q = Integer.parseInt(x)-1;                      //int id 
                
                
                    System.out.println("You entered a new comment : " + comment );
                
                issueList.getIssues().get(q).addComment(comment_id,comment,currentSession.getUsername());
                
        }
          }
    
          
         
              
      

//           try (FileWriter file = new FileWriter("data.json")) 
//        {
//        JSONArray createIssue = new JSONArray();
//        System.out.println(issueList.toString());
//        createIssue.put(issueList.toString());
//        
            //We can write any JSONArray or JSONObject instance to the file
            //file.write(createIssue.toString()); 
          //file.flush();
// 
//        } 
//        catch (IOException e) 
//        {
//            e.printStackTrace();
//        }
          
    }   
    
//    public void newComment(String x) {
//        
//        Scanner s = new Scanner(System.in);
//        System.out.println("\'r\' to react");
//                System.out.println("\'c\' to comment");
//                System.out.println("");
//                System.out.println("");
//                
//                String z=s.nextLine();
//                
//                if (z.equals("r")) {
//                Scanner input = new Scanner(System.in);
//                System.out.println("Choose which comment ID to react");
//                int selectCommentID = input.nextInt();
//                System.out.println("Choose a reaction. [happy/sad/angry]");
//                int q = Integer.parseInt(x)-1;
//                String f =s.nextLine();
//   
//                issueList.getIssues().get(q).getComments().get(selectCommentID).addReact(f);
//   
//                }
//                
//                else if (z.equals("c")) {
//                    
//                Scanner input = new Scanner(System.in);
//                String comment = input.next();
//                int comment_id = currentSession.getUserID();
//                int q = Integer.parseInt(x)-1;
//                
//                issueList.getIssues().get(q).addComment(comment_id,comment,currentSession.getUsername());
//    }
                
    
    
    
    
    

    
    public int size(){
        return issueList.getIssues().size();
    }
}
